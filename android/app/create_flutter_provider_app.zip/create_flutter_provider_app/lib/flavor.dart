/*
Available commands:

flutter run --flavor dev -t lib/main.dart
flutter run --flavor prod -t lib/main_prod.dart
 */

enum Flavor {dev, prod}