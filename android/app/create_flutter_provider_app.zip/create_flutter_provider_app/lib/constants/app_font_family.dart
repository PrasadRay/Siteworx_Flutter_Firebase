class AppFontFamily{
  AppFontFamily._();

  static String productSans = "ProductSans";
  static String roboto = "Roboto";
}